package com.example.pulsetest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView result;
    ImageView good;
    ImageView average;
    ImageView bad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Bundle extras = getIntent().getExtras();
        String resultKey = extras.getString("result");

        good = (ImageView) findViewById(R.id.imageViewG);
        average = (ImageView) findViewById(R.id.imageViewA);
        bad = (ImageView) findViewById(R.id.imageViewB);

        result = findViewById(R.id.result);
        System.out.println(resultKey);
        switch (resultKey){
            case ("1"):
                result.setText("Введенные значения соответствуют отсутствию переутомления");
                good.setVisibility(View.VISIBLE);
                break;
            case ("2"):
                result.setText("Введенные значения соответствуют наличию небольшого переутомления");
                average.setVisibility(View.VISIBLE);
                break;
            case ("3"):
                result.setText("Введенные значения соответствуют наличию сильного переутомления");
                bad.setVisibility(View.VISIBLE);
                break;
            case ("4"):
                result.setText("Ошибка, неккоректные данные");
                break;
            default:
                break;
        }
    }

}